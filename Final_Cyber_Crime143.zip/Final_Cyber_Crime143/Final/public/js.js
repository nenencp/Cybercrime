document.addEventListener('DOMContentLoaded', function() {
    const counters = document.querySelectorAll('.count-digit');

    // Function to start counting for a specific counter
    const startCount = (counter) => {
        const target = +counter.innerText; // Get the target number from the HTML
        counter.innerText = '0'; // Start from 0
        const increment = Math.ceil(target / 100); // Calculate increment value
        let count = 0; // Current count
        
        const updateCount = () => {
            count += increment; // Increment the count
            if (count < target) {
                counter.innerText = count; // Update the count in HTML
                requestAnimationFrame(updateCount); // Use requestAnimationFrame for smoothness
            } else {
                counter.innerText = target; // Ensure we set the final value
            }
        };

        updateCount(); // Start the counting
    };

    // Start counting for each counter element
    counters.forEach(counter => {
        startCount(counter);
    });
});




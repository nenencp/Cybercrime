require("dotenv").config(); // Load environment variables from .env file
const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const mysql = require("mysql");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const requestIp = require("request-ip");
var smtpTransport = require('nodemailer-smtp-transport');

const app = express();

// MySQL Connection
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "Midterm143" // Database name
});

connection.connect((err) => {
    if (err) {
        console.error("Error connecting to database:", err);
        return;
    }
    console.log("Connected to database");
});

// Middleware
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(requestIp.mw());
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
    secret: process.env.SESSION_SECRET || "default_secret", // Use a secret from environment variables
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // Set to true if using HTTPS in production
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // Session expires in 24 hours
    }
}));

// Middleware to check if the user is logged in, but exclude certain routes like /forgot and /logout
function checkAuthenticated(req, res, next) {
    const publicRoutes = ["/login", "/register", "/forgot", "/logout", "/changepassword", "/auth"]; // Public routes
    if (publicRoutes.includes(req.path)) {
        return next(); // Allow these routes to be accessed without logging in
    }

    if (req.session.loggedin) {
        next(); // Continue to the requested route if logged in
    } else {
        res.send(
            `<script>alert('Please login first!'); window.location.href='/login';</script>`
        ); // Redirect to login page with an alert if not logged in
    }
}

// Apply the middleware to all routes except login, register, forgot, and logout
app.use((req, res, next) => {
    checkAuthenticated(req, res, next);
});

app.get("/login", (req, res) => {
    const userIP = req.clientIp;

    // เช็กว่า IP ของผู้ใช้ได้ถูกบันทึกไว้ในวันนี้หรือยัง
    connection.query(
        "SELECT * FROM keepcounter WHERE date = CURDATE() AND ip = ?",
        [userIP],
        (err, results) => {
            if (err) return res.status(500).send("Database error");

            if (results.length === 0) {
                // ถ้า IP นี้ยังไม่ถูกบันทึกวันนี้ ให้เพิ่มลงในฐานข้อมูล
                connection.query(
                    "INSERT INTO keepcounter (ip, date) VALUES (?, CURDATE())",
                    [userIP],
                    (insertErr) => {
                        if (insertErr) console.error("Error inserting IP:", insertErr);
                    }
                );
            }

            // นับจำนวนผู้เยี่ยมชมทั้งหมดในวันนี้
            connection.query(
                "SELECT COUNT(*) AS dailyCount FROM keepcounter WHERE date = CURDATE()",
                (countErr, countResult) => {
                    if (countErr) return res.status(500).send("Database error");

                    // ส่งค่า counter ไปยังหน้า login.ejs
                    res.render("login.ejs", { counter: countResult[0].dailyCount });
                }
            );
        }
    );
});


// Register Route
app.get("/register", (req, res) => {
    res.render("register.ejs");
});

app.post("/register", async (req, res) => {
    const { fullname, date, sex, phone, email, username, password, repassword } = req.body;

    // Validation checks
    if (!fullname || !date || !sex || !phone || !email || !username || !password || !repassword) {
        return res.status(400).send("All fields are required");
    }

    if (password !== repassword) {
        return res.status(400).send("Passwords do not match");
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = { fullname, date, sex, phone, email, username, password: hashedPassword };

        // Insert the user into the database
        connection.query("INSERT INTO accregister SET ?", user, (err) => {
            if (err) {
                console.error("Error registering user:", err);
                return res.status(500).send("Registration failed");
            }
            // Redirect to login page after successful registration
            res.redirect("/login");
        });
    } catch (err) {
        console.error("Error hashing password:", err);
        res.status(500).send("An error occurred during registration");
    }
});

app.get("/login", (req, res) => {
    if (req.session.loggedin) {
        return res.redirect("/webboard"); // Redirect to webboard if already logged in
    }
    res.render("login.ejs"); // Render the login page
});


app.post("/auth", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.send("Please enter Username and Password");
    }

    connection.query(
        "SELECT * FROM accregister WHERE username = ?", [username],
        (err, results) => {
            if (err) return res.status(500).send("Database error");

            if (results.length > 0) {
                bcrypt.compare(password, results[0].password, (bcryptErr, match) => {
                    if (bcryptErr) return res.status(500).send("Bcrypt error");

                    if (match) {
                        req.session.loggedin = true;
                        req.session.username = username; // Store username in session
                        res.redirect("/webboard"); // Redirect to the webboard after successful login
                    } else {
                        res.send("Incorrect Password");
                    }
                });
            } else {
                res.send("User not found");
            }
        }
    );
});


// Sign-Out Route
app.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) return res.status(500).send("Error signing out");
        res.redirect("/login");
    });
});

// Webboard Route
app.get("/webboard", (req, res) => {
    if (!req.session.loggedin) {
        return res.send("Login required");
    }

    connection.query("SELECT * FROM accregister", (err, results) => {
        if (err) return res.status(500).send("Database error");
        res.render("Home.ejs", { posts: results });
    });
});

// Forgot Password Route
app.get("/forgot", (req, res) => {
    res.render("loginforgot.ejs");
});

app.post("/forgot", (req, res) => {
    const { email, username } = req.body; // ดึง email และ username จาก request body

    // ค้นหาจากฐานข้อมูลที่มีทั้ง email และ username
    connection.query(
        "SELECT * FROM accregister WHERE email = ? AND username = ?", [email, username], 
        (err, results) => {
            if (err) return res.status(500).send("Database error");

            // ถ้าพบข้อมูลในฐานข้อมูล
            if (results.length > 0) {
                const tempPassword = Math.random().toString(36).substring(2, 10); // สร้างรหัสผ่านชั่วคราว
                const hashedTempPassword = bcrypt.hashSync(tempPassword, 10); // แฮชรหัสผ่าน

                // อัปเดตรหัสผ่านในฐานข้อมูล
                connection.query(
                    "UPDATE accregister SET password = ? WHERE email = ? AND username = ?", 
                    [hashedTempPassword, email, username], 
                    (updateErr) => {
                        if (updateErr) return res.send("Error updating password");

                        // ส่งอีเมล
                        sendMail(email, "Temporary Password", `Your temporary password is: ${tempPassword}`);

                        // ส่งข้อความ HTML พร้อมปุ่ม "Go to Login" 
                        res.send(`
                            <p>Temporary password sent to your email, Please check your email‼️
                            </p>
                            <a href="/login">
                                <button style="
                                    font-size: 20px; 
                                    padding: 15px 30px; 
                                    background-color: #6597c9; 
                                    color: white; 
                                    border: none; 
                                    border-radius: 5px;
                                    cursor: pointer;
                                    text-align: center;">
                                    Go to Login
                                </button>
                            </a>
                        `);
                    }
                );
            } else {
                res.send("Email or Username not found");
            }
        }
    );
});


// Send Email
function sendMail(to, subject, text) {
    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    const mailOptions = {
        from: `"Your App" <${process.env.EMAIL_USER}>`,
        to,
        subject,
        text
    };

    transporter.sendMail(mailOptions, (err, info) => {
        if (err) console.error("Error sending email:", err);
    });
}
app.get('/changepassword', checkAuthenticated, (req, res) => {
    res.render('changepassword');
});

app.post('/changepassword', (req, res) => {
    const { oldPassword, newPassword } = req.body;

    connection.query('SELECT password FROM accregister WHERE username = ?', [req.session.username], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            bcrypt.compare(oldPassword, results[0].password, function(err, result) {
                if (result) {
                    bcrypt.hash(newPassword, 10, (err, hashPassword) => {
                        if (err) throw err;

                        connection.query('UPDATE accregister SET password = ? WHERE username = ?', [hashPassword, req.session.username], (err) => {
                            if (err) throw err;
                            res.redirect('/changepassword');
                        });
                    });
                } else {
                    res.redirect('/changepassword'); // Old password did not match
                }
            });
        } else {
            req.session.destroy();
            res.redirect('/login');
        }
    });
});

app.post("/auth", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.send("Please enter Username and Password");
    }

    connection.query(
        "SELECT * FROM accregister WHERE username = ?", [username],
        (err, results) => {
            if (err) return res.status(500).send("Database error");

            if (results.length > 0) {
                bcrypt.compare(password, results[0].password, (bcryptErr, match) => {
                    if (bcryptErr) return res.status(500).send("Bcrypt error");

                    if (match) {
                        req.session.loggedin = true;
                        req.session.username = username;
                        res.redirect("/webboard");
                    } else {
                        res.send("Incorrect Password");
                    }
                });
            } else {
                res.send("User not found");
            }
        }
    );
});

// Additional Routes
app.get("/contact", (req, res) => res.render("contact"));
app.get("/home", (req, res) => res.render("home"));
app.get("/know", (req, res) => res.render("know"));
app.get("/how", (req, res) => res.render("how"));
app.get("/news", (req, res) => res.render("news"));
app.get("/login", (req, res) => res.render("login"));


// Start Server
app.listen(9005, () => {
    console.log("Server running at http://localhost:9005");
});

let a = Math.random();
console.log(a);

console.log(a.toString().length);

console.log("########");
let b = Math.random();
console.log(b);

console.log(b.toString(36));
//สร้างรหัสผ่านชั่วคราว 0.fhgguhf33
console.log(b.toString(36).substring(2,12));
//fhgguhf33